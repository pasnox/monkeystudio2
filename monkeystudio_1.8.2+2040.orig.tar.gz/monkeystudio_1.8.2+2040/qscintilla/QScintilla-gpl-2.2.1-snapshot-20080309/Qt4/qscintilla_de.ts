<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="de">
<defaultcodec></defaultcodec>
<context>
    <name>QsciCommand</name>
    <message>
        <location filename="qscicommandset.cpp" line="146"/>
        <source>Move left one character</source>
        <translation>Ein Zeichen nach links</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="181"/>
        <source>Move right one character</source>
        <translation>Ein Zeichen nach rechts</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="90"/>
        <source>Move up one line</source>
        <translation>Eine Zeile nach oben</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="62"/>
        <source>Move down one line</source>
        <translation>Eine Zeile nach unten</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="216"/>
        <source>Move left one word part</source>
        <translation>Ein Wortteil nach links</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="230"/>
        <source>Move right one word part</source>
        <translation>Ein Wortteil nach rechts</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="160"/>
        <source>Move left one word</source>
        <translation>Ein Wort nach links</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="195"/>
        <source>Move right one word</source>
        <translation>Ein Wort nach rechts</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="244"/>
        <source>Move to first visible character in line</source>
        <translation>Zum ersten sichtbaren Zeichen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="293"/>
        <source>Move to end of line</source>
        <translation>Zum Ende der Zeile</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="76"/>
        <source>Scroll view down one line</source>
        <translation>Eine Zeile nach unten rollen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="104"/>
        <source>Scroll view up one line</source>
        <translation>Eine Zeile nach oben rollen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="342"/>
        <source>Move up one page</source>
        <translation>Eine Seite hoch</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="363"/>
        <source>Move down one page</source>
        <translation>Eine Seite nach unten</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="258"/>
        <source>Move to start of text</source>
        <translation>Zum Textanfang</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="307"/>
        <source>Move to end of text</source>
        <translation>Zum Textende</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="482"/>
        <source>Indent one level</source>
        <translation>Eine Ebene einrücken</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="489"/>
        <source>Move back one indentation level</source>
        <translation>Eine Ebene ausrücken</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="475"/>
        <source>Select all text</source>
        <translation>Gesamten Text auswählen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="153"/>
        <source>Extend selection left one character</source>
        <translation>Auswahl um ein Zeichen nach links erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="188"/>
        <source>Extend selection right one character</source>
        <translation>Auswahl um ein Zeichen nach rechts erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="97"/>
        <source>Extend selection up one line</source>
        <translation>Auswahl um eine Zeile nach oben erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="69"/>
        <source>Extend selection down one line</source>
        <translation>Auswahl um eine Zeile nach unten erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="223"/>
        <source>Extend selection left one word part</source>
        <translation>Auswahl um einen Wortteil nach links erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="237"/>
        <source>Extend selection right one word part</source>
        <translation>Auswahl um einen Wortteil nach rechts erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="167"/>
        <source>Extend selection left one word</source>
        <translation>Auswahl um ein Wort nach links erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="202"/>
        <source>Extend selection right one word</source>
        <translation>Auswahl um ein Wort nach rechts erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="251"/>
        <source>Extend selection to first visible character in line</source>
        <translation>Auswahl bis zum ersten sichtbaren Zeichen erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="279"/>
        <source>Extend selection to start of line</source>
        <translation>Auswahl bis zum Zeilenanfang erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="300"/>
        <source>Extend selection to end of line</source>
        <translation>Auswahl bis zum Zeilenende erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="349"/>
        <source>Extend selection up one page</source>
        <translation>Auswahl um eine Seite nach oben erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="370"/>
        <source>Extend selection down one page</source>
        <translation>Auswahl um eine Seite nach unten erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="265"/>
        <source>Extend selection to start of text</source>
        <translation>Auswahl bis zum Textanfang erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="314"/>
        <source>Extend selection to end of text</source>
        <translation>Auswahl bis zum Textende erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="440"/>
        <source>Delete previous character</source>
        <translation>Zeichen links löschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="580"/>
        <source>Delete previous character if not at line start</source>
        <translation>Zeichen links löschen, wenn nicht am Zeilenanfang</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="384"/>
        <source>Delete current character</source>
        <translation>Aktuelles Zeichen löschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="447"/>
        <source>Delete word to left</source>
        <translation>Wort links löschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="398"/>
        <source>Delete word to right</source>
        <translation>Wort rechts löschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="461"/>
        <source>Delete line to left</source>
        <translation>Zeile links löschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="405"/>
        <source>Delete line to right</source>
        <translation>Zeile rechts löschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="496"/>
        <source>Insert new line</source>
        <translation>Neue Zeile einfügen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="538"/>
        <source>Delete current line</source>
        <translation>Aktuelle Zeile löschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="552"/>
        <source>Swap current and previous lines</source>
        <translation>Aktuelle Zeile mit vorhergehender tauschen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="531"/>
        <source>Cut current line</source>
        <translation>Aktuelle Zeile ausschneiden</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="391"/>
        <source>Cut selection</source>
        <translation>Auswahl ausschneiden</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="426"/>
        <source>Copy selection</source>
        <translation>Auswahl kopieren</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="419"/>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="468"/>
        <source>Redo last command</source>
        <translation>Letzten Befehl wiederholen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="454"/>
        <source>Undo the last command</source>
        <translation>Letzten Befehl rückgängig</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="433"/>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="412"/>
        <source>Toggle insert/overtype</source>
        <translation>Einfügen/Überschreiben umschalten</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="566"/>
        <source>Convert selection to lower case</source>
        <translation>Auswahl in Kleinbuchstaben umwandeln</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="573"/>
        <source>Convert selection to upper case</source>
        <translation>Auswahl in Großbuchstaben umwandeln</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="503"/>
        <source>Zoom in</source>
        <translation>Vergrößern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="510"/>
        <source>Zoom out</source>
        <translation>Verkleinern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="118"/>
        <source>Move up one paragraph</source>
        <translation>Einen Absatz nach oben</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="132"/>
        <source>Move down one paragraph</source>
        <translation>Einen Absatz nach unten</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="125"/>
        <source>Extend selection up one paragraph</source>
        <translation>Auswahl um einen Absatz nach oben erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="139"/>
        <source>Extend selection down one paragraph</source>
        <translation>Auswahl um einen Absatz nach unten erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="545"/>
        <source>Copy current line</source>
        <translation>Aktuelle Zeile kopieren</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="83"/>
        <source>Extend rectangular selection down one line</source>
        <translation>Rechteckige Auswahl um eine Zeile nach unten erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="111"/>
        <source>Extend rectangular selection up one line</source>
        <translation>Rechteckige Auswahl um eine Zeile nach oben erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="174"/>
        <source>Extend rectangular selection left one character</source>
        <translation>Rechteckige Auswahl um ein Zeichen nach links erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="209"/>
        <source>Extend rectangular selection right one character</source>
        <translation>Rechteckige Auswahl um ein Zeichen nach rechts erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="272"/>
        <source>Move to start of displayed line</source>
        <translation>Zum Beginn der angezeigten Zeile</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="286"/>
        <source>Extend rectangular selection to first visible character in line</source>
        <translation>Rechteckige Auswahl bis zum ersten sichtbaren Zeichen erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="321"/>
        <source>Move to end of displayed line</source>
        <translation>Zum Ende der angezeigten Zeile</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="328"/>
        <source>Extend selection to end of displayed line</source>
        <translation>Auswahl bis zum Ende der angezeigten Zeile erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="335"/>
        <source>Extend rectangular selection to end of line</source>
        <translation>Rechteckige Auswahl bis zum Zeilenende erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="356"/>
        <source>Extend rectangular selection up one page</source>
        <translation>Rechteckige Auswahl um eine Seite nach oben erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="377"/>
        <source>Extend rectangular selection down one page</source>
        <translation>Rechteckige Auswahl um eine Seite nach unten erweitern</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="517"/>
        <source>Set zoom</source>
        <translation>Zoom einstellen</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="524"/>
        <source>Formfeed</source>
        <translation>Seitenumbruch</translation>
    </message>
    <message>
        <location filename="qscicommandset.cpp" line="559"/>
        <source>Duplicate selection</source>
        <translation>Auswahl duplizieren</translation>
    </message>
</context>
<context>
    <name>QsciLexerBash</name>
    <message>
        <location filename="qscilexerbash.cpp" line="214"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="217"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="220"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="223"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="226"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="229"/>
        <source>Double-quoted string</source>
        <translation>Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="232"/>
        <source>Single-quoted string</source>
        <translation>Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="235"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="238"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="241"/>
        <source>Scalar</source>
        <translation>Skalar</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="244"/>
        <source>Parameter expansion</source>
        <translation>Parametererweiterung</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="247"/>
        <source>Backticks</source>
        <translation>Backticks</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="250"/>
        <source>Here document delimiter</source>
        <translation>Here Dokument-Begrenzer</translation>
    </message>
    <message>
        <location filename="qscilexerbash.cpp" line="253"/>
        <source>Single-quoted here document</source>
        <translation>Here Dokument in Hochkommata</translation>
    </message>
</context>
<context>
    <name>QsciLexerBatch</name>
    <message>
        <location filename="qscilexerbatch.cpp" line="185"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerbatch.cpp" line="188"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerbatch.cpp" line="191"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerbatch.cpp" line="194"/>
        <source>Label</source>
        <translation>Marke</translation>
    </message>
    <message>
        <location filename="qscilexerbatch.cpp" line="203"/>
        <source>Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="qscilexerbatch.cpp" line="206"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerbatch.cpp" line="197"/>
        <source>Hide command character</source>
        <translation>&quot;Befehl verbergen&quot; Zeichen</translation>
    </message>
    <message>
        <location filename="qscilexerbatch.cpp" line="200"/>
        <source>External command</source>
        <translation>Externer Befehl</translation>
    </message>
</context>
<context>
    <name>QsciLexerCMake</name>
    <message>
        <location filename="qscilexercmake.cpp" line="204"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="207"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="210"/>
        <source>String</source>
        <translation>Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="213"/>
        <source>Left quoted string</source>
        <translation>Links quotierte Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="216"/>
        <source>Right quoted string</source>
        <translation>Rechts quotierte Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="219"/>
        <source>Function</source>
        <translation>Funktion</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="222"/>
        <source>Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="225"/>
        <source>Label</source>
        <translation>Marke</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="228"/>
        <source>User defined</source>
        <translation>Nutzer definiert</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="231"/>
        <source>WHILE block</source>
        <translation>WHILE Block</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="234"/>
        <source>FOREACH block</source>
        <translation>FOREACH Block</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="237"/>
        <source>IF block</source>
        <translation>IF Block</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="240"/>
        <source>MACRO block</source>
        <translation>MACRO Block</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="243"/>
        <source>Variable within a string</source>
        <translation>Variable in einer Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexercmake.cpp" line="246"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
</context>
<context>
    <name>QsciLexerCPP</name>
    <message>
        <location filename="qscilexercpp.cpp" line="287"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="290"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="293"/>
        <source>Double-quoted string</source>
        <translation>Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="296"/>
        <source>Single-quoted string</source>
        <translation>Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="299"/>
        <source>Pre-processor block</source>
        <translation>Preprozessorblock</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="302"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="305"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="308"/>
        <source>Unclosed string</source>
        <translation>Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="275"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="278"/>
        <source>C comment</source>
        <translation>C Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="281"/>
        <source>C++ comment</source>
        <translation>C++ Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="284"/>
        <source>JavaDoc style C comment</source>
        <translation>JavaDoc C Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="311"/>
        <source>JavaDoc style C++ comment</source>
        <translation>JavaDoc C++ Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="317"/>
        <source>JavaDoc keyword</source>
        <translation>JavaDoc Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="320"/>
        <source>JavaDoc keyword error</source>
        <translation>JavaDoc Schlüsselwortfehler</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="314"/>
        <source>Secondary keywords and identifiers</source>
        <translation>Sekundäre Schlusselwörter und Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexercpp.cpp" line="323"/>
        <source>Global classes and typedefs</source>
        <translation>Globale Klassen und typdefinitionen</translation>
    </message>
</context>
<context>
    <name>QsciLexerCSS</name>
    <message>
        <location filename="qscilexercss.cpp" line="243"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="246"/>
        <source>Tag</source>
        <translation>Tag</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="249"/>
        <source>Class selector</source>
        <translation>Klassenselektor</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="252"/>
        <source>Pseudo-class</source>
        <translation>Pseudoklasse</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="255"/>
        <source>Unknown pseudo-class</source>
        <translation>Unbekannte Pseudoklasse</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="258"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="261"/>
        <source>CSS1 property</source>
        <translation>CSS1 Eigenschaft</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="264"/>
        <source>Unknown property</source>
        <translation>Unbekannte Eigenschaft</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="267"/>
        <source>Value</source>
        <translation>Wert</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="270"/>
        <source>ID selector</source>
        <translation>ID-Selektor</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="273"/>
        <source>Important</source>
        <translation>Wichtig</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="276"/>
        <source>@-rule</source>
        <translation>@-Regel</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="279"/>
        <source>Double-quoted string</source>
        <translation>Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="282"/>
        <source>Single-quoted string</source>
        <translation>Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="285"/>
        <source>CSS2 property</source>
        <translation>CSS2 Eigenschaft</translation>
    </message>
    <message>
        <location filename="qscilexercss.cpp" line="288"/>
        <source>Attribute</source>
        <translation>Attribut</translation>
    </message>
</context>
<context>
    <name>QsciLexerCSharp</name>
    <message>
        <location filename="qscilexercsharp.cpp" line="118"/>
        <source>Verbatim string</source>
        <translation>Uninterpretierte Zeichenkette</translation>
    </message>
</context>
<context>
    <name>QsciLexerD</name>
    <message>
        <location filename="qscilexerd.cpp" line="277"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="280"/>
        <source>Block comment</source>
        <translation>Blockkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="283"/>
        <source>Line comment</source>
        <translation>Zeilenkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="286"/>
        <source>DDoc style block comment</source>
        <translation>DDoc Blockkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="289"/>
        <source>Nesting comment</source>
        <translation>schachtelbarer Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="292"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="295"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="298"/>
        <source>Secondary keyword</source>
        <translation>Sekundäres Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="301"/>
        <source>Documentation keyword</source>
        <translation>Dokumentationsschlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="304"/>
        <source>Type definition</source>
        <translation>Typdefinition</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="307"/>
        <source>String</source>
        <translation>Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="310"/>
        <source>Unclosed string</source>
        <translation>Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="313"/>
        <source>Character</source>
        <translation>Zeichen</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="316"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="319"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="322"/>
        <source>DDoc style line comment</source>
        <translation>DDoc Zeilenkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="325"/>
        <source>DDoc keyword</source>
        <translation>DDoc Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerd.cpp" line="328"/>
        <source>DDoc keyword error</source>
        <translation>DDoc Schlüsselwortfehler</translation>
    </message>
</context>
<context>
    <name>QsciLexerDiff</name>
    <message>
        <location filename="qscilexerdiff.cpp" line="114"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerdiff.cpp" line="117"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerdiff.cpp" line="120"/>
        <source>Command</source>
        <translation>Befehl</translation>
    </message>
    <message>
        <location filename="qscilexerdiff.cpp" line="123"/>
        <source>Header</source>
        <translation>Kopfzeilen</translation>
    </message>
    <message>
        <location filename="qscilexerdiff.cpp" line="126"/>
        <source>Position</source>
        <translation>Position</translation>
    </message>
    <message>
        <location filename="qscilexerdiff.cpp" line="129"/>
        <source>Removed line</source>
        <translation>Entfernte Zeile</translation>
    </message>
    <message>
        <location filename="qscilexerdiff.cpp" line="132"/>
        <source>Added line</source>
        <translation>Hinzugefügte Zeile</translation>
    </message>
</context>
<context>
    <name>QsciLexerHTML</name>
    <message>
        <location filename="qscilexerhtml.cpp" line="553"/>
        <source>HTML default</source>
        <translation>HTML Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="556"/>
        <source>Tag</source>
        <translation>Tag</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="559"/>
        <source>Unknown tag</source>
        <translation>Unbekanntes Tag</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="562"/>
        <source>Attribute</source>
        <translation>Attribut</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="565"/>
        <source>Unknown attribute</source>
        <translation>Unbekanntes Attribut</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="568"/>
        <source>HTML number</source>
        <translation>HTML Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="571"/>
        <source>HTML double-quoted string</source>
        <translation>HTML Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="574"/>
        <source>HTML single-quoted string</source>
        <translation>HTML Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="577"/>
        <source>Other text in a tag</source>
        <translation>Anderer Text in einem Tag</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="580"/>
        <source>HTML comment</source>
        <translation>HTML Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="583"/>
        <source>Entity</source>
        <translation>Entität</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="586"/>
        <source>End of a tag</source>
        <translation>Tagende</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="589"/>
        <source>Start of an XML fragment</source>
        <translation>Beginn eines XML Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="592"/>
        <source>End of an XML fragment</source>
        <translation>Ende eines XML Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="595"/>
        <source>Script tag</source>
        <translation>Skript Tag</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="598"/>
        <source>Start of an ASP fragment with @</source>
        <translation>Beginn eines ASP Fragmentes mit @</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="601"/>
        <source>Start of an ASP fragment</source>
        <translation>Beginn eines ASP Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="604"/>
        <source>CDATA</source>
        <translation>CDATA</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="607"/>
        <source>Start of a PHP fragment</source>
        <translation>Beginn eines PHP Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="610"/>
        <source>Unquoted HTML value</source>
        <translation>HTML Wert ohne Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="613"/>
        <source>ASP X-Code comment</source>
        <translation>ASP X-Code Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="616"/>
        <source>SGML default</source>
        <translation>SGML Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="619"/>
        <source>SGML command</source>
        <translation>SGML Befehl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="622"/>
        <source>First parameter of an SGML command</source>
        <translation>Erster Parameter eines SGML Befehls</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="625"/>
        <source>SGML double-quoted string</source>
        <translation>SGML Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="628"/>
        <source>SGML single-quoted string</source>
        <translation>SGML Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="631"/>
        <source>SGML error</source>
        <translation>SGML Fehler</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="634"/>
        <source>SGML special entity</source>
        <translation>SGML Spezielle Entität</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="637"/>
        <source>SGML comment</source>
        <translation>SGML Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="640"/>
        <source>First parameter comment of an SGML command</source>
        <translation>Kommentar des ersten Parameters eines SGML Befehls</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="643"/>
        <source>SGML block default</source>
        <translation>SGML Standardblock</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="646"/>
        <source>Start of a JavaScript fragment</source>
        <translation>Beginn eines JavaScript Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="649"/>
        <source>JavaScript default</source>
        <translation>JavaScript Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="652"/>
        <source>JavaScript comment</source>
        <translation>JavaScript Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="655"/>
        <source>JavaScript line comment</source>
        <translation>JavaScript Zeilenkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="658"/>
        <source>JavaDoc style JavaScript comment</source>
        <translation>JavaDoc JavaScript Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="661"/>
        <source>JavaScript number</source>
        <translation>JavaScript Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="664"/>
        <source>JavaScript word</source>
        <translation>JavaScript Wort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="667"/>
        <source>JavaScript keyword</source>
        <translation>JavaScript Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="670"/>
        <source>JavaScript double-quoted string</source>
        <translation>JavaScript Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="673"/>
        <source>JavaScript single-quoted string</source>
        <translation>JavaScript Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="676"/>
        <source>JavaScript symbol</source>
        <translation>JavaScript Symbol</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="679"/>
        <source>JavaScript unclosed string</source>
        <translation>JavaScript Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="682"/>
        <source>JavaScript regular expression</source>
        <translation>JavaScript Regulärer Ausdruck</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="685"/>
        <source>Start of an ASP JavaScript fragment</source>
        <translation>Beginn eines ASP JavaScript Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="688"/>
        <source>ASP JavaScript default</source>
        <translation>ASP JavaScript Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="691"/>
        <source>ASP JavaScript comment</source>
        <translation>ASP JavaScript Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="694"/>
        <source>ASP JavaScript line comment</source>
        <translation>ASP JavaScript Zeilenkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="697"/>
        <source>JavaDoc style ASP JavaScript comment</source>
        <translation>JavaDoc ASP JavaScript Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="700"/>
        <source>ASP JavaScript number</source>
        <translation>ASP JavaScript Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="703"/>
        <source>ASP JavaScript word</source>
        <translation>ASP JavaScript Wort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="706"/>
        <source>ASP JavaScript keyword</source>
        <translation>ASP JavaScript Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="709"/>
        <source>ASP JavaScript double-quoted string</source>
        <translation>ASP JavaScript Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="712"/>
        <source>ASP JavaScript single-quoted string</source>
        <translation>ASP JavaScript Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="715"/>
        <source>ASP JavaScript symbol</source>
        <translation>ASP JavaScript Symbol</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="718"/>
        <source>ASP JavaScript unclosed string</source>
        <translation>ASP JavaScript Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="721"/>
        <source>ASP JavaScript regular expression</source>
        <translation>ASP JavaScript Regulärer Ausdruck</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="724"/>
        <source>Start of a VBScript fragment</source>
        <translation>Beginn eines VBScript Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="727"/>
        <source>VBScript default</source>
        <translation>VBScript Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="730"/>
        <source>VBScript comment</source>
        <translation>VBScript Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="733"/>
        <source>VBScript number</source>
        <translation>VBScript Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="736"/>
        <source>VBScript keyword</source>
        <translation>VBScript Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="739"/>
        <source>VBScript string</source>
        <translation>VBScript Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="742"/>
        <source>VBScript identifier</source>
        <translation>VBScript Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="745"/>
        <source>VBScript unclosed string</source>
        <translation>VBScript Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="748"/>
        <source>Start of an ASP VBScript fragment</source>
        <translation>Beginn eines ASP VBScript Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="751"/>
        <source>ASP VBScript default</source>
        <translation>ASP VBScript Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="754"/>
        <source>ASP VBScript comment</source>
        <translation>ASP VBScript Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="757"/>
        <source>ASP VBScript number</source>
        <translation>ASP VBScript Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="760"/>
        <source>ASP VBScript keyword</source>
        <translation>ASP VBScript Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="763"/>
        <source>ASP VBScript string</source>
        <translation>ASP VBScript Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="766"/>
        <source>ASP VBScript identifier</source>
        <translation>ASP VBScript Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="769"/>
        <source>ASP VBScript unclosed string</source>
        <translation>ASP VBScript Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="772"/>
        <source>Start of a Python fragment</source>
        <translation>Beginn eines Python Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="775"/>
        <source>Python default</source>
        <translation>Python Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="778"/>
        <source>Python comment</source>
        <translation>Python Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="781"/>
        <source>Python number</source>
        <translation>Python Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="784"/>
        <source>Python double-quoted string</source>
        <translation>Python Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="787"/>
        <source>Python single-quoted string</source>
        <translation>Python Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="790"/>
        <source>Python keyword</source>
        <translation>Python Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="793"/>
        <source>Python triple double-quoted string</source>
        <translation>Python Zeichenkette in dreifachen Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="796"/>
        <source>Python triple single-quoted string</source>
        <translation>Python Zeichenkette in dreifachen Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="799"/>
        <source>Python class name</source>
        <translation>Python Klassenname</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="802"/>
        <source>Python function or method name</source>
        <translation>Python Funktions- oder Methodenname</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="805"/>
        <source>Python operator</source>
        <translation>Python Operator</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="808"/>
        <source>Python identifier</source>
        <translation>Python Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="811"/>
        <source>Start of an ASP Python fragment</source>
        <translation>Beginn eines ASP Python Fragmentes</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="814"/>
        <source>ASP Python default</source>
        <translation>ASP Python Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="817"/>
        <source>ASP Python comment</source>
        <translation>ASP Python Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="820"/>
        <source>ASP Python number</source>
        <translation>ASP Python Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="823"/>
        <source>ASP Python double-quoted string</source>
        <translation>ASP Python Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="826"/>
        <source>ASP Python single-quoted string</source>
        <translation>ASP Python Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="829"/>
        <source>ASP Python keyword</source>
        <translation>ASP Python Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="832"/>
        <source>ASP Python triple double-quoted string</source>
        <translation>ASP Python Zeichenkette in dreifachen Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="835"/>
        <source>ASP Python triple single-quoted string</source>
        <translation>ASP Python Zeichenkette in dreifachen Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="838"/>
        <source>ASP Python class name</source>
        <translation>ASP Python Klassenname</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="841"/>
        <source>ASP Python function or method name</source>
        <translation>ASP Python Funktions- oder Methodenname</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="844"/>
        <source>ASP Python operator</source>
        <translation>ASP Python Operator</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="847"/>
        <source>ASP Python identifier</source>
        <translation>ASP Python Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="850"/>
        <source>PHP default</source>
        <translation>PHP Standard</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="853"/>
        <source>PHP double-quoted string</source>
        <translation>PHP Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="856"/>
        <source>PHP single-quoted string</source>
        <translation>PHP Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="859"/>
        <source>PHP keyword</source>
        <translation>PHP Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="862"/>
        <source>PHP number</source>
        <translation>PHP Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="868"/>
        <source>PHP comment</source>
        <translation>PHP Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="871"/>
        <source>PHP line comment</source>
        <translation>PHP Zeilenkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="874"/>
        <source>PHP double-quoted variable</source>
        <translation>PHP Variable in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="877"/>
        <source>PHP operator</source>
        <translation>PHP Operator</translation>
    </message>
    <message>
        <location filename="qscilexerhtml.cpp" line="865"/>
        <source>PHP variable</source>
        <translation>PHP Variable</translation>
    </message>
</context>
<context>
    <name>QsciLexerIDL</name>
    <message>
        <location filename="qscilexeridl.cpp" line="112"/>
        <source>UUID</source>
        <translation>UUID</translation>
    </message>
</context>
<context>
    <name>QsciLexerJavaScript</name>
    <message>
        <location filename="qscilexerjavascript.cpp" line="120"/>
        <source>Regular expression</source>
        <translation>Regulärer Ausdruck</translation>
    </message>
</context>
<context>
    <name>QsciLexerLua</name>
    <message>
        <location filename="qscilexerlua.cpp" line="228"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="231"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="234"/>
        <source>Line comment</source>
        <translation>Zeilenkommentar</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="237"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="240"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="243"/>
        <source>String</source>
        <translation>Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="246"/>
        <source>Character</source>
        <translation>Zeichen</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="249"/>
        <source>Literal string</source>
        <translation>Uninterpretierte Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="252"/>
        <source>Preprocessor</source>
        <translation>Preprozessor</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="255"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="258"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="261"/>
        <source>Unclosed string</source>
        <translation>Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="264"/>
        <source>Basic functions</source>
        <translation>Basisfunktionen</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="267"/>
        <source>String, table and maths functions</source>
        <translation>Zeichenketten-, Tabelle- und mathematische Funktionen</translation>
    </message>
    <message>
        <location filename="qscilexerlua.cpp" line="270"/>
        <source>Coroutines, i/o and system facilities</source>
        <translation>Koroutinen, I/O- und Systemfunktionen</translation>
    </message>
</context>
<context>
    <name>QsciLexerMakefile</name>
    <message>
        <location filename="qscilexermakefile.cpp" line="139"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexermakefile.cpp" line="142"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexermakefile.cpp" line="145"/>
        <source>Preprocessor</source>
        <translation>Preprozessor</translation>
    </message>
    <message>
        <location filename="qscilexermakefile.cpp" line="148"/>
        <source>Variable</source>
        <translation>Variable</translation>
    </message>
    <message>
        <location filename="qscilexermakefile.cpp" line="151"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexermakefile.cpp" line="154"/>
        <source>Target</source>
        <translation>Ziel</translation>
    </message>
    <message>
        <location filename="qscilexermakefile.cpp" line="157"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
</context>
<context>
    <name>QsciLexerPOV</name>
    <message>
        <location filename="qscilexerpov.cpp" line="288"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="291"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="294"/>
        <source>Comment line</source>
        <translation>Kommentarzeile</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="297"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="300"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="303"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="306"/>
        <source>String</source>
        <translation>Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="309"/>
        <source>Unclosed string</source>
        <translation>Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="312"/>
        <source>Directive</source>
        <translation>Direktive</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="315"/>
        <source>Bad directive</source>
        <translation>Ungültige Direktive</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="318"/>
        <source>Objects, CSG and appearance</source>
        <translation>Objekte, CSG und Erscheinung</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="321"/>
        <source>Types, modifiers and items</source>
        <translation>Typen, Modifizierer und Items</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="324"/>
        <source>Predefined identifiers</source>
        <translation>Vordefinierter Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="327"/>
        <source>Predefined functions</source>
        <translation>Vordefinierte Funktion</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="330"/>
        <source>User defined 1</source>
        <translation>Nutzer definiert 1</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="333"/>
        <source>User defined 2</source>
        <translation>Nutzer definiert 2</translation>
    </message>
    <message>
        <location filename="qscilexerpov.cpp" line="336"/>
        <source>User defined 3</source>
        <translation>Nutzer definiert 3</translation>
    </message>
</context>
<context>
    <name>QsciLexerPerl</name>
    <message>
        <location filename="qscilexerperl.cpp" line="271"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="274"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="277"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="280"/>
        <source>POD</source>
        <translation>POD</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="283"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="286"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="289"/>
        <source>Double-quoted string</source>
        <translation>Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="292"/>
        <source>Single-quoted string</source>
        <translation>Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="295"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="298"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="301"/>
        <source>Scalar</source>
        <translation>Skalar</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="304"/>
        <source>Array</source>
        <translation>Feld</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="307"/>
        <source>Hash</source>
        <translation>Hash</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="310"/>
        <source>Symbol table</source>
        <translation>Symboltabelle</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="313"/>
        <source>Regular expression</source>
        <translation>Regulärer Ausdruck</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="316"/>
        <source>Substitution</source>
        <translation>Ersetzung</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="319"/>
        <source>Backticks</source>
        <translation>Backticks</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="322"/>
        <source>Data section</source>
        <translation>Datensektion</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="325"/>
        <source>Here document delimiter</source>
        <translation>Here Dokument-Begrenzer</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="328"/>
        <source>Single-quoted here document</source>
        <translation>Here Dokument in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="331"/>
        <source>Double-quoted here document</source>
        <translation>Here Dokument in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="334"/>
        <source>Backtick here document</source>
        <translation>Here Dokument in Backticks</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="337"/>
        <source>Quoted string (q)</source>
        <translation>Zeichenkette (q)</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="340"/>
        <source>Quoted string (qq)</source>
        <translation>Zeichenkette (qq)</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="343"/>
        <source>Quoted string (qx)</source>
        <translation>Zeichenkette (qx)</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="346"/>
        <source>Quoted string (qr)</source>
        <translation>Zeichenkette (qr)</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="349"/>
        <source>Quoted string (qw)</source>
        <translation>Zeichenkette (qw)</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="352"/>
        <source>POD verbatim</source>
        <translation>POD wörtlich</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="355"/>
        <source>Subroutine prototype</source>
        <translation>Subroutinen Prototyp</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="358"/>
        <source>Format identifier</source>
        <translation>Formatidentifikator</translation>
    </message>
    <message>
        <location filename="qscilexerperl.cpp" line="361"/>
        <source>Format body</source>
        <translation>Formatzweig</translation>
    </message>
</context>
<context>
    <name>QsciLexerProperties</name>
    <message>
        <location filename="qscilexerproperties.cpp" line="134"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerproperties.cpp" line="137"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerproperties.cpp" line="140"/>
        <source>Section</source>
        <translation>Abschnitt</translation>
    </message>
    <message>
        <location filename="qscilexerproperties.cpp" line="143"/>
        <source>Assignment</source>
        <translation>Zuweisung</translation>
    </message>
    <message>
        <location filename="qscilexerproperties.cpp" line="146"/>
        <source>Default value</source>
        <translation>Standardwert</translation>
    </message>
</context>
<context>
    <name>QsciLexerPython</name>
    <message>
        <location filename="qscilexerpython.cpp" line="244"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="247"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="250"/>
        <source>Double-quoted string</source>
        <translation>Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="253"/>
        <source>Single-quoted string</source>
        <translation>Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="256"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="259"/>
        <source>Triple single-quoted string</source>
        <translation>Zeichenkette in dreifachen Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="262"/>
        <source>Triple double-quoted string</source>
        <translation>Zeichenkette in dreifachen Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="265"/>
        <source>Class name</source>
        <translation>Klassenname</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="268"/>
        <source>Function or method name</source>
        <translation>Funktions- oder Methodenname</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="271"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="274"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="277"/>
        <source>Comment block</source>
        <translation>Kommentarblock</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="280"/>
        <source>Unclosed string</source>
        <translation>Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="241"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="283"/>
        <source>Highlighted identifier</source>
        <translation>Hervorgehobener Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerpython.cpp" line="286"/>
        <source>Decorator</source>
        <translation>Dekorator</translation>
    </message>
</context>
<context>
    <name>QsciLexerRuby</name>
    <message>
        <location filename="qscilexerruby.cpp" line="258"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="264"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="270"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="276"/>
        <source>Double-quoted string</source>
        <translation>Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="279"/>
        <source>Single-quoted string</source>
        <translation>Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="273"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="282"/>
        <source>Class name</source>
        <translation>Klassenname</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="285"/>
        <source>Function or method name</source>
        <translation>Funktions- oder Methodenname</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="288"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="291"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="261"/>
        <source>Error</source>
        <translation>Fehler</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="267"/>
        <source>POD</source>
        <translation>POD</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="294"/>
        <source>Regular expression</source>
        <translation>Regulärer Ausdruck</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="297"/>
        <source>Global</source>
        <translation>Global</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="300"/>
        <source>Symbol</source>
        <translation>Symbol</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="303"/>
        <source>Module name</source>
        <translation>Modulname</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="306"/>
        <source>Instance variable</source>
        <translation>Instanzvariable</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="309"/>
        <source>Class variable</source>
        <translation>Klassenvariable</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="312"/>
        <source>Backticks</source>
        <translation>Backticks</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="315"/>
        <source>Data section</source>
        <translation>Datensektion</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="318"/>
        <source>Here document delimiter</source>
        <translation>Here Dokument-Begrenzer</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="321"/>
        <source>Here document</source>
        <translation>Here Dokument</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="324"/>
        <source>%q string</source>
        <translation>%q Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="327"/>
        <source>%Q string</source>
        <translation>%Q Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="330"/>
        <source>%x string</source>
        <translation>%x Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="333"/>
        <source>%r string</source>
        <translation>%r Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="336"/>
        <source>%w string</source>
        <translation>%w Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="339"/>
        <source>Demoted keyword</source>
        <translation>zurückgestuftes Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="342"/>
        <source>stdin</source>
        <translation>Stdin</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="345"/>
        <source>stdout</source>
        <translation>Stdout</translation>
    </message>
    <message>
        <location filename="qscilexerruby.cpp" line="348"/>
        <source>stderr</source>
        <translation>Stderr</translation>
    </message>
</context>
<context>
    <name>QsciLexerSQL</name>
    <message>
        <location filename="qscilexersql.cpp" line="264"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="267"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="276"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="279"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="285"/>
        <source>Single-quoted string</source>
        <translation>Zeichenkette in Hochkommata</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="294"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="297"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="270"/>
        <source>Comment line</source>
        <translation>Kommentarzeile</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="273"/>
        <source>JavaDoc style comment</source>
        <translation>JavaDoc Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="282"/>
        <source>Double-quoted string</source>
        <translation>Zeichenkette in Anführungszeichen</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="288"/>
        <source>SQL*Plus keyword</source>
        <translation>SQL*Plus Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="291"/>
        <source>SQL*Plus prompt</source>
        <translation>SQL*Plus Eingabe</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="300"/>
        <source>SQL*Plus comment</source>
        <translation>SQL*Plus Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="303"/>
        <source># comment line</source>
        <translation># Kommentarzeile</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="306"/>
        <source>JavaDoc keyword</source>
        <translation>JavaDoc Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="309"/>
        <source>JavaDoc keyword error</source>
        <translation>JavaDoc Schlüsselwortfehler</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="312"/>
        <source>User defined 1</source>
        <translation>Nutzer definiert 1</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="315"/>
        <source>User defined 2</source>
        <translation>Nutzer definiert 2</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="318"/>
        <source>User defined 3</source>
        <translation>Nutzer definiert 3</translation>
    </message>
    <message>
        <location filename="qscilexersql.cpp" line="321"/>
        <source>User defined 4</source>
        <translation>Nutzer definiert 4</translation>
    </message>
</context>
<context>
    <name>QsciLexerTCL</name>
    <message>
        <location filename="qscilexertcl.cpp" line="303"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="306"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="309"/>
        <source>Comment line</source>
        <translation>Kommentarzeile</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="312"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="315"/>
        <source>Quoted keyword</source>
        <translation>angeführtes Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="318"/>
        <source>Quoted string</source>
        <translation>Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="321"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="324"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="327"/>
        <source>Substitution</source>
        <translation>Ersetzung</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="330"/>
        <source>Brace substitution</source>
        <translation>Klammerersetzung</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="333"/>
        <source>Modifier</source>
        <translation>Modifizierer</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="336"/>
        <source>Expand keyword</source>
        <translation>Erweiterungsschlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="339"/>
        <source>TCL keyword</source>
        <translation>TCL Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="342"/>
        <source>Tk keyword</source>
        <translation>Tk Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="345"/>
        <source>iTCL keyword</source>
        <translation>iTCL Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="348"/>
        <source>Tk command</source>
        <translation>Tk Befehl</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="351"/>
        <source>User defined 1</source>
        <translation>Nutzer definiert 1</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="354"/>
        <source>User defined 2</source>
        <translation>Nutzer definiert 2</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="357"/>
        <source>User defined 3</source>
        <translation>Nutzer definiert 3</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="360"/>
        <source>User defined 4</source>
        <translation>Nutzer definiert 4</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="363"/>
        <source>Comment box</source>
        <translation>Kommentarbox</translation>
    </message>
    <message>
        <location filename="qscilexertcl.cpp" line="366"/>
        <source>Comment block</source>
        <translation>Kommentarblock</translation>
    </message>
</context>
<context>
    <name>QsciLexerTeX</name>
    <message>
        <location filename="qscilexertex.cpp" line="199"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexertex.cpp" line="202"/>
        <source>Special</source>
        <translation>Spezial</translation>
    </message>
    <message>
        <location filename="qscilexertex.cpp" line="205"/>
        <source>Group</source>
        <translation>Gruppe</translation>
    </message>
    <message>
        <location filename="qscilexertex.cpp" line="208"/>
        <source>Symbol</source>
        <translation>Symbol</translation>
    </message>
    <message>
        <location filename="qscilexertex.cpp" line="211"/>
        <source>Command</source>
        <translation>Befehl</translation>
    </message>
    <message>
        <location filename="qscilexertex.cpp" line="214"/>
        <source>Text</source>
        <translation>Text</translation>
    </message>
</context>
<context>
    <name>QsciLexerVHDL</name>
    <message>
        <location filename="qscilexervhdl.cpp" line="220"/>
        <source>Default</source>
        <translation>Standard</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="223"/>
        <source>Comment</source>
        <translation>Kommentar</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="226"/>
        <source>Comment line</source>
        <translation>Kommentarzeile</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="229"/>
        <source>Number</source>
        <translation>Zahl</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="232"/>
        <source>String</source>
        <translation>Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="235"/>
        <source>Operator</source>
        <translation>Operator</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="238"/>
        <source>Identifier</source>
        <translation>Bezeichner</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="241"/>
        <source>Unclosed string</source>
        <translation>Unbeendete Zeichenkette</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="244"/>
        <source>Keyword</source>
        <translation>Schlüsselwort</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="247"/>
        <source>Standard operator</source>
        <translation>Standardoperator</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="250"/>
        <source>Attribute</source>
        <translation>Attribut</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="253"/>
        <source>Standard function</source>
        <translation>Standardfunktion</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="256"/>
        <source>Standard package</source>
        <translation>Standardpaket</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="259"/>
        <source>Standard type</source>
        <translation>Standardtyp</translation>
    </message>
    <message>
        <location filename="qscilexervhdl.cpp" line="262"/>
        <source>User defined</source>
        <translation>Nutzer definiert</translation>
    </message>
</context>
</TS>
