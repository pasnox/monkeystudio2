#ifndef $basename.upper$_H
#define $basename.upper$_H

#include <QObject>

class $basename$ : public QObject
{
	Q_OBJECT

public:
	$basename$( QObject* = 0 );
	~$basename$();

};

#endif // $basename.upper$_H
