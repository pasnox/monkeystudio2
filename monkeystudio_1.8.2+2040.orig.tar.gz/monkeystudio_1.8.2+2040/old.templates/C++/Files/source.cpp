#include "$basename$.h"

$basename$::$basename$()
{
}

$basename$::~$basename$()
{
}
