#include "$basename$.h"

$basename$::$basename$( QWidget* w )
	: QWidget( w )
{
}

$basename$::~$basename$()
{
}
