#ifndef $basename.upper$_H
#define $basename.upper$_H

class $basename$
{
public:
	$basename$();
	~$basename$();

};

#endif // $basename.upper$_H
