#ifndef $basename.upper$_H
#define $basename.upper$_H

#include <QMainWindow>

class $basename$ : public QMainWindow
{
	Q_OBJECT

public:
	$basename$( QWidget* = 0 );
	~$basename$();

};

#endif // $basename.upper$_H
