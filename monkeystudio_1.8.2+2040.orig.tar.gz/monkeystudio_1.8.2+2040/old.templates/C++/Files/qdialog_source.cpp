#include "$basename$.h"

$basename$::$basename$( QWidget* w )
	: QDialog( w )
{
}

$basename$::~$basename$()
{
}
