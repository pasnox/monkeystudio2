#ifndef $basename.upper$_H
#define $basename.upper$_H

#include <QWidget>

class $basename$ : public QWidget
{
	Q_OBJECT

public:
	$basename$( QWidget* = 0 );
	~$basename$();

};

#endif // $basename.upper$_H
