#include "$basename$.h"

$basename$::$basename$( QObject* o )
	: QObject( o )
{
}

$basename$::~$basename$()
{
}
