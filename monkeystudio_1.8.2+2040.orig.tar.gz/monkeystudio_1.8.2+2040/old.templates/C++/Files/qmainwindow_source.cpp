#include "$basename$.h"

$basename$::$basename$( QWidget* w )
	: QMainWindow( w )
{
}

$basename$::~$basename$()
{
}
