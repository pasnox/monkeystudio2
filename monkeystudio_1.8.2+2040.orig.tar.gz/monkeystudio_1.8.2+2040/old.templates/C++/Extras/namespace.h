#ifndef $basename.upper$_H
#define $basename.upper$_H

namespace $basename$
{
	void defaultMember();
};

#endif // $basename.upper$_H
