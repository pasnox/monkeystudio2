#include "$basename$.h"

$basename$::defaultMember()
{
}

