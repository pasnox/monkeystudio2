#import "$Base file name$.h"

$Class name$::$Class name$()
	: $Parent class$()
{
}

$Class name$::~$Class name$()
{
}
