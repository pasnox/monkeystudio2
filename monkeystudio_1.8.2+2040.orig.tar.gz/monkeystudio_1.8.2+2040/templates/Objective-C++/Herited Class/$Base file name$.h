#ifndef $Base file name.upper$_H
#define $Base file name.upper$_H

#import "$Parent's include file$"

class $Class name$ : public $Parent class$
{
	$OBJECT (empty if no)$
public:
	$Class name$();
	~$Class name$();

};

#endif // $Base file name.upper$_H
