#import "$Base file name$.h"

$Class name$::$Class name$()
{
}

$Class name$::~$Class name$()
{
}
