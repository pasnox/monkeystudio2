#ifndef $Base file name.upper$_H
#define $Base file name.upper$_H

class $Class name$
{
public:
	$Class name$();
	~$Class name$();

};

#endif // $Base file name.upper$_H
