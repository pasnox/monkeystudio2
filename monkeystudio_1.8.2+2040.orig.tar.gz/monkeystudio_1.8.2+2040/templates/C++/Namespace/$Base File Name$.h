#ifndef $Base File Name.upper$_H
#define $Base File Name.upper$_H

namespace $Namespace Name$
{
};

#endif // $Base File Name.upper$_H
