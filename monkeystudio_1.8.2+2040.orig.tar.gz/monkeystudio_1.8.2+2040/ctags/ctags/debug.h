#ifndef  _DEBUG_H
#define  _DEBUG_H

# define DebugStatement(x)
# define Assert(c)


#endif  /* _DEBUG_H */
