#include "../src/qscintillamanager/pEditor.h"
#include "../src/qscintillamanager/qSciShortcutsManager.h"
#include "../src/qscintillamanager/SearchThread.h"

#include "../src/qscintillamanager/ui/pSearch.h"
