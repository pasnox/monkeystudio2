#include "../src/toolsmanager/pDesktopApplications.h"
#include "../src/toolsmanager/pToolsManager.h"

#include "../src/toolsmanager/ui/UIDesktopTools.h"
#include "../src/toolsmanager/ui/UIToolsEdit.h"
