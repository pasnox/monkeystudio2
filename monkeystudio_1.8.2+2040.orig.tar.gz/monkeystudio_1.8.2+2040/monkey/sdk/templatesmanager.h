#include "../src/templatesmanager/pTemplatesManager.h"

#include "../src/templatesmanager/ui/UITemplatesWizard.h"
