#include "../src/maininterface/UIMain.h"
#include "../src/maininterface/ui/UIAbout.h"
#include "../src/maininterface/ui/UISettings.h"
#include "../src/maininterface/ui/UITranslator.h"
