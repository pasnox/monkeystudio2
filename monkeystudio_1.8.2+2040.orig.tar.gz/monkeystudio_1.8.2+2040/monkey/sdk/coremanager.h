#include "../src/coremanager/MonkeyCore.h"
